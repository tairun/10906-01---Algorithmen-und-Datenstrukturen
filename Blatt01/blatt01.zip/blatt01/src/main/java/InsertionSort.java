public class InsertionSort {

  /** 
   * Insertionsort algorithm for int arrays, sorting the input array in place.
   **/
  public static void sort(int[] array) {
    // Aufgabe 1 (a)
  
  }

}
